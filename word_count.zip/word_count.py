'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
import re
import string

def word_count(args):
    content = args.get('words')
    words = ""
    punctuation2 = "['-]"
    regex2 = r"(\s)"
    
    for value in content:
        if re.search(regex2, value):
            value = ' '
            words = words + value
        else:
            if not re.search(punctuation2, value) and re.search('['+string.punctuation+']', value):
                value = ' '
            words = words + value
            
    words = words.split(' ')
    dictionary = {}
    for word in words:
        if not word == "":
            if word in dictionary:
                dictionary[word] = dictionary.get(word) + 1
            else:
                dictionary[word] = 1
                
    return dictionary


