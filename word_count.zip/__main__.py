'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
import pika
from word_count import word_count
from COS_backend import COS_backend

def main (args):
    config = args.get("config_file")
    text = args.get("text")
    index = args.get("index")
    amqp = args.get("amqp")
    amqp_url = amqp.get('amqp')
    cos_backend = COS_backend(config)
    params_word_count = {'words':text}
    resultat_word_count = word_count(params_word_count)
    cos_backend.put_object('sanchoericbucket', 'word_count_' + str(index) + '.txt', str(resultat_word_count))  
    params = pika.URLParameters(amqp_url)
    connection = pika.BlockingConnection(params)
    channel = connection.channel() 
    channel.queue_declare(queue='word_count_queue')
    message='word_count_'+str(index)+'.txt'
    channel.basic_publish(exchange='', routing_key='word_count_queue', body=message)
    connection.close()
    result = {'resultat':'be'}
    return result