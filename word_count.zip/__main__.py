'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
from word_count import word_count
from COS_backend import COS_backend

def main (args):
    config = args.get("config_file")
    text = args.get("text")
    index = args.get("index")
    cos_backend = COS_backend(config)
    #carreguem el text que volem passar per parametre al word_count
    params_word_count = {'words':text}
    resultat_word_count = word_count(params_word_count)
    cos_backend.put_object('sanchoericbucket', 'word_count_' + str(index) + '.txt', str(resultat_word_count))  
    result = {'resultat':'be'}
    return result