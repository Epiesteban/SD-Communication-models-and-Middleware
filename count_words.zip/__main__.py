'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
from count_words import count_words
from COS_backend import COS_backend
from ast import literal_eval

def main (args):
    config = args.get("config_file")
    cos_backend = COS_backend(config)
    final_reducer = cos_backend.get_object('sanchoericbucket', 'reducer.txt')
    final_decode = final_reducer.decode('utf-8')
    diccionari_reducer = literal_eval(final_decode)
    diccionari_entrada = {'all':diccionari_reducer}
    resultat = count_words(diccionari_entrada)
    cos_backend.put_object('sanchoericbucket', 'count_words.txt', str(resultat))
    result = {'resultat':'be'}
    
    return result
