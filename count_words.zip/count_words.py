'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
def count_words(args):
    content = args.get('all')
    num_words = 0
    words = content.keys()
    
    for word in words:
        num_words = num_words + content[word]
        
    return {"Number of words": num_words}