'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
from reducer import reducer
from COS_backend import COS_backend
from ast import literal_eval

def main (args):
    config = args.get("config_file")
    cos_backend = COS_backend(config)
    llista_txt = cos_backend.list_objects('sanchoericbucket', 'word_count')
    llista_final = []
    for i in llista_txt:
        nom = i['Key']
        objecte = cos_backend.get_object('sanchoericbucket', nom)
        cadena = objecte.decode('utf-8')
        dicc_entrada = literal_eval(cadena)
        llista_final.append(dicc_entrada)
    
    diccionari_entrada = {'all':llista_final}
    resultat_reducer = reducer(diccionari_entrada)
    cos_backend.put_object('sanchoericbucket', 'reducer.txt', str(resultat_reducer))
    result = {'resultat':'be'}
    
    return result