'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
import pika
from count_words import count_words
from reducer import reducer
from COS_backend import COS_backend
from ast import literal_eval
 
def main(args):
    global amqp_url
    global connection
    global channel
    global num_workers
    global cos_backend
    global dictionaries
    dictionaries = []
    config = args.get("config_file")
    amqp = args.get("amqp")
    amqp_url = amqp.get('amqp')
    num_workers = args.get("num_workers")
    cos_backend = COS_backend(config)
    params = pika.URLParameters(amqp_url)
    connection = pika.BlockingConnection(params)
    channel = connection.channel()
    channel.queue_declare(queue = 'word_count_queue') 
    channel.queue_declare(queue = 'message_queue')
    
    def on_message(channel, method_frame, header_frame, body):
        channel.basic_ack(delivery_tag = method_frame.delivery_tag)
        finish = 0
        num_files = cos_backend.list_objects('sanchoericbucket','word_count_')
        if len(num_files) == num_workers:
            finish = 1
        else:
            finish = 0        
        
        if finish == 1:
            id_file = 0
            while id_file < num_workers:
                file_dicc = num_files[id_file]
                name_file = file_dicc['Key']
                dictionary = cos_backend.get_object('sanchoericbucket', name_file)
                dictionary = dictionary.decode('utf-8')
                dictionary = literal_eval(dictionary)
                dictionaries.append(dictionary)
                id_file = id_file + 1
                
            params = {'all':dictionaries}
            final_dicc = reducer(params)
            cos_backend.put_object('sanchoericbucket','reducer_amqp.txt', str(final_dicc))
            params = {'all':final_dicc}
            num_words = count_words(params)
            cos_backend.put_object('sanchoericbucket', 'count_words_amqp.txt', str(num_words))
            channel.stop_consuming()
    
    channel.basic_consume(on_message, queue = 'word_count_queue')
    channel.start_consuming()
    channel.basic_publish(exchange = '', routing_key = 'message_queue', body = 'stop')
    connection.close()
    result = {'resultat':'be'}
    
    return result