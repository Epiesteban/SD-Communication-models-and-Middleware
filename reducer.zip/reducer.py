'''
Created on 19 abr. 2019

@author: Aleix Sancho i Eric Pi
'''
def reducer(args):
    content = args.get('all')
    dictionary = {}
    for words in content:
        for word in words:
            if word in dictionary:
                dictionary[word] = dictionary.get(word) + words.get(word)
            else:
                dictionary[word] = words.get(word)

    return dictionary
    